function Locales(id, cmRL, cmnID, gRL, aL, wL, roomsL, dL, servicesL, priceL, img1, img2, img3, img4, img5) {
    this.id = id, //id
        this.cmRL = cmRL, //registro en la COMUNA --> 1 AL 9
        this.cmnID = cmnID, // numeero comuna quue pertenence
        this.gRL = gRL, // RREGISTROO GENEERAL DE LOCALEES DEJAR EN BLANCO
        this.aL = aL, // ADDRESS --> UBICACION LOCAL
        this.wL = wL, // WEB PAGE
        this.roomsL = roomsL, // CITAR SOLAMENTE NOMBRE DE HABIIACION
        this.dL = dL // DESCRIPTION --> 1 ranglon de parrafoo del hotel
    this.servicesL = sL, // SERVICES --> servicios generales en una palabra para cada topico
        this.priceL = priceL, // --> precio MENOR VALOR - MAYOR VALOR (rango dee precio)
        this.img1 = img1,
        this.img2 = img2,
        this.img3 = img3,
        this.img4 = img4,
        this.img5 = img5
}
Locales()
    /**300 x 250 c/imagen salvo en una carpeta gral, el nombre de c/foto es el nombre del hotel + 01 + el nombre de la habitacion + separadas por guion bajo + guardar en jpg minimo 3 fotos  */

/*COMUNA 1*/
/**CONSTITUCION */
/*Hotel Acuario */
let localesCreate = new Locales(null, null, 1, null, " Brasil 1777", "4304-3579", ["Normal", "Especial", "Suite", "Suite Especial", , "hidro"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Constitucion", "https://ibb.co/XFZSMpZ", "https://ibb.co/12nJbN3", "https://ibb.co/LdT0b0H", "https://ibb.co/1XFCdH6", "https://ibb.co/30LJTK2")

/**Hotel Origen */
let localesCreate = new Locales(null, null, 1, null, "Pavón 1719 ", " 11 2308 7383", ["Standar", "Especial", "Suite", "Hidro vip", "Cinema", "Ducha Esosesa"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Constitucion", "https://ibb.co/3SLmfsk", "https://ibb.co/3SLmfsk", "https://ibb.co/xFWZh93", "https://ibb.co/mXkv4t1", "https://ibb.co/b62TwhS", 2 "https://ibb.co/kGQ4736")



/*Hotel el Velero*/

let localesCreate = new Locales(null, null, 1, null, "Pavón 1541", "11 4306-7626", ["Especial", "Estandar", "Hidromasaje", "Suite", "Baño Romano", "Intermedia"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Constitucion", "https://ibb.co/yVYbXgt", "https://ibb.co/pL8BY87", "https://ibb.co/89TgHtd", "https://ibb.co/fd92pVP", "https://ibb.co/r5PqQ8Y", "https://ibb.co/QKjXWH0")




/**MONSERRAT */
/**Cedro Azul */

let localesCreate = new Locales(null, null, 1, null, "Pres. Luis Saenz Peña 1026,", "4305-6500", ["Normal", "Espacial", "Vip", "Cedro Azul"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Monserrat", "https://ibb.co/kXXhmTr", "https://ibb.co/BP10WYt", "https://ibb.co/VLqZmvM", "https://ibb.co/N1VqMYT", "https://ibb.co/PrQWxD5", "https://ibb.co/R4t6ZzF", "https://ibb.co/GQXzXFx")

/**Atlas */
let localesCreate = new Locales(null, null, 1, null, "Solis 681", "4381.5397", ["Base", "Relax", "RelaxDuo", "Atlas", "Atlas Vip", "Atlas Plus"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Monserrat", "https://ibb.co/S7cFv1y", "https://ibb.co/GRdts9J", "https://ibb.co/gJSmsXw", "https://ibb.co/G2MJ76G", "https://ibb.co/WtZFM4g", "https://ibb.co/kHSPL15", "https://ibb.co/JrZyvfW")

/*Plus*/
let localesCreate = new Locales(null, null, 1, null, "Av. Independencia 1484", "43814705", ["Suite", "Ejecutiva", "Imperial", "Relax", "Loft"], "1000 a 1300", "Telo en barrio Monserrat", "https://ibb.co/0X0C5kZ"
    "https://ibb.co/j5BLhP6"
    "https://ibb.co/F8LNYpW"
    "https://ibb.co/jJ00YMC"
    "https://ibb.co/QPt7Yzw")


/*----------------------------------------------------------------------------------------------*/
/**COMUNA 12*/

/**Villa Urquiza */
/**Effiel */

let localesCreate = new Locales(null, null, 1, null, "F. D. Roosevelt 5135/39", " Wp:1145227127", ["Base", "Relax", "RelaxDuo", "Atlas", "Atlas Vip", "Atlas Plus"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Villa Urquiza", "https://ibb.co/VS9jxvz", "https://ibb.co/MD7MqzS", "https://ibb.co/YR7Qq8s", "https://ibb.co/F0gDTzt", "https://ibb.co/373d8V8", "https://ibb.co/jbfbY1b")


/*------------------------------------------------------------------------------------------------*/

/**COMUNA 14 */

/**Palermo */
/**Amancay */

let localesCreate = new Locales(null, null, 1, null, "Guemes 4859", "1147739660", ["Base", "Relax", "RelaxDuo", "Atlas", "Atlas Vip", "Atlas Plus"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Palermo", "https://ibb.co/ZxKQ0MD", "https://ibb.co/b2WtZCv", "https://ibb.co/YQjpKhm", "https://ibb.co/sQQhtvr", "https://ibb.co/KWB684q")


/*---------------------------------------------------------------------------------------*/
/**COMUNA 2 */
/**Recoleta */
/**D'OR */

let localesCreate = new Locales(null, null, 1, null, "Anchorena 1293", "49614881", ["Especial1", "Especial1", "Suite2", "Suite3", "Suite3", "SuiteHidro4", "SuiteHidro4", "SuiteHidro4"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Recoleta", "https://ibb.co/hWjN8Mv",
        "https://ibb.co/jbV82tz",
        "https://ibb.co/w67rWq3",
        "https://ibb.co/f4jhgLT",
        "https://ibb.co/ZBbJcpW",
        "https://ibb.co/Rpb9yn6",
        "https://ibb.co/BscF9S2",
        "https://ibb.co/c2qrBVV")
    /*-----------------------------------------------------------------------------------*/
    /**COMUNA 13 */

/**Belgrano */
/**El Cisne */
let localesCreate = new Locales(null, null, 1, null, "Congreso 1939", "47827214", ["Especial", "Hidromasaje", "Normal", "Hidrozono"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Belgrano", "https://ibb.co/thHdhXc",
    "https://ibb.co/0XRR24D",
    "https://ibb.co/LvH7ssT",
    "https://ibb.co/wWRwcy0",
    "https://ibb.co/xmzWRd7",
    "https://ibb.co/mc6ZcQz")

/**St. James */
let localesCreate = new Locales(null, null, 1, null, "Superi 2339", "45411751", ["st james", "Imperail", "Ejecutiva", "Relax", "Suite", "Normal"], "2200 a 3500", "Telo en barrio Belgrano", "https://ibb.co/LCKWNms",
    "https://ibb.co/XsqD9zy",
    "https://ibb.co/XpCvZBt",
    "https://ibb.co/Sxgjffs",
    "https://ibb.co/7KDfLTr",
    "https://ibb.co/M1mZM4G")

/**Hirondelle */
let localesCreate = new Locales(null, null, 1, null, "Palpa 2457", "47843856", ["Platino", "Imperial", "Ejecutiva", "Relax", "Suite"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Belgrano", "https://ibb.co/thHdhXc", "https://ibb.co/mDy13mr",
    "https://ibb.co/KWSM0b4",
    "https://ibb.co/YBR66zX",
    "https://ibb.co/Jy1zF27",
    "https://ibb.co/vhtR4qr")

/**Hotel Que */
let localesCreate = new Locales(null, null, 1, null, "Montañeses 1872", "47832246", ["Noche de Bodas", "Party Room", "Taconeando", "Tropical", "Poses Eroticas", "Cama Redonda", "Caribeña", "Cirsence", "Que placer", "Que pasion", "Isleña", "Chinatown", "Noche de Bs.As", "Amanecer", "Paraiso Terrenal", "Kamasutra", "Alegria", "Romantica Especial", "Moulin Roube", "Stripper", "Disco Pub", "Romantiquisima", "Ejecutiva", "Gimnasta", "Sado Fantasia"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Belgrano", "https://ibb.co/p3gLrRS",
    "https://ibb.co/Vg4x1h1",
    "https://ibb.co/x6Wsz7r",
    "https://ibb.co/h8HGTjg",
    "https://ibb.co/xKZB89S",
    "https://ibb.co/SKFc82W",
    "https://ibb.co/crVGC5m",
    "https://ibb.co/TwHMTpX",
    "https://ibb.co/BC7n1vz",
    "https://ibb.co/YDTdsrQ",
    "https://ibb.co/DwnT9b7",
    "https://ibb.co/WcdhDNR",
    "https://ibb.co/FD4jM38",
    "https://ibb.co/FzJv7Q8",
    "https://ibb.co/LRVwwwR",
    "https://ibb.co/yRNKv8k",
    "https://ibb.co/tMn05cy",
    "https://ibb.co/FWzn46F",
    "https://ibb.co/VLzGPB9",
    "https://ibb.co/RNY3CkJ",
    "https://ibb.co/j4TK2fR",
    "https://ibb.co/RNVQrCS",
    "https://ibb.co/bXgphNz",
    "https://ibb.co/mTBGy1H",
    "https://ibb.co/QK5L7Rj")


/**Hotel el Bosque */
let localesCreate = new Locales(null, null, 1, null, "Catañeda 1848", "4784 4093", ["Especial", "Con Hidro", "Standard"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Belgrano", "https://ibb.co/ZxyGCVW",
"https://ibb.co/xDS64RG",
"https://ibb.co/yYQKmXC")

)


/**Hotel Black Jack */
let localesCreate = new Locales(null, null, 1, null, "Paroissien 1935", "4701 6255", ["Normal", "Deseo", "Pasion Clasica", "Pasion Africana", "Pasion All White", "Pasion Espejada", "Exotic", "Suite Relax", "Suite Tantra", "Suite Zen", "Suite Desing"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Belgrano", "https://ibb.co/dt6wkQJ",
        "https://ibb.co/74kcs1t",
        "https://ibb.co/Cv5DFCb",
        "https://ibb.co/Df6nsWV",
        "https://ibb.co/w4H4Zcn",
        "https://ibb.co/dtT2wC6",
        "https://ibb.co/3vsT6qF",
        "https://ibb.co/c3LWfQ9",
        "https://ibb.co/Lz7wSVT")
    /**relax-tantra faltan */

/*------------------------------------------------------------------------------------------------*/
/**COMUNA 6 */

/**Caballito */
/**Waikiki */
let localesCreate = new Locales(null, null, 1, null, "Rio de Janeiro 271", "49824741", ["HidroDance", "SuiteJunior", "Apart Spa2", "Apart Spa2", "Suite Spa", "Suite Hidro Dance3", "Suite Hidro Dance3", "Suite Confort", "Suite Spa", "Suite Confort4", "Suite Confort4", "Suite Spa", "Standar", "Suite Junior5", "Suite Junior5 "], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Caballito  ", "https://ibb.co/P9mg8t2"
    "https://ibb.co/WncB9Sr"
    "https://ibb.co/s3D3DxL"
    "https://ibb.co/1mWp5Nv"
    "https://ibb.co/nD5s2hJ"
    "https://ibb.co/8db1MFB"
    "https://ibb.co/QrFmj7T"
    "https://ibb.co/bFSPcKs"
    "https://ibb.co/mcjF0gd"
    "https://ibb.co/7bsM0n1"
    "https://ibb.co/vz4Ffm4"
    "https://ibb.co/4PfHpjx"
    "https://ibb.co/t8R2wRh"
    "https://ibb.co/0QKqLT4"
    "https://ibb.co/C550xZV")


/**Amapola */
let localesCreate = new Locales(null, null, 1, null, "Yerbal 615", "49024881", ["Normal", "Suite", "Ducha Escosesa", "Suite Hidro"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Caballito", "https://ibb.co/41w7tRN"
    "https://ibb.co/V9Xfxr7"
    "https://ibb.co/Dk21YFJ"
    "https://ibb.co/WzDSXL1")

/**Coquett */
let localesCreate = new Locales(null, null, 1, null, "Dr. Juan Felipe Aranguren 50", "49824517", ["Suite Ejecutiva", "Suite1", "Suite1", "Suite Escosesa1", "Coquett3", "Coquett3", "Suite Vapor4", "Suite Vapor4", "Coquett", "Suite Escosesa", "Platino5", "Platino5"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Caballito", "https://ibb.co/km91myH"
    "https://ibb.co/ggSC00V"
    "https://ibb.co/Jd6Q0ym"
    "https://ibb.co/6wRqwKv"
    "https://ibb.co/9cg1sk0"
    "https://ibb.co/qW7rcPC"
    "https://ibb.co/2Kmy4q5"
    "https://ibb.co/BwzqZ9q"
    "https://ibb.co/vqq20Sk"
    "https://ibb.co/5ngSc49"
    "https://ibb.co/D4qhthv"
    "https://ibb.co/VVQPtbD")

/**Platino */
let localesCreate = new Locales(null, null, 1, null, "Alberdi 920", "44323653", ["Platino", "Platino", "Filandesa", "Escosesa", "Relax", "Hidro Dance", "Neon"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Caballito", "https://ibb.co/Kr1ztRp"
    "https://ibb.co/MBGvknn"
    "https://ibb.co/2tkq5b7"
    "https://ibb.co/C06ZFRT"
    "https://ibb.co/BjqyB2s"
    "https://ibb.co/nfCY3xh"
    "https://ibb.co/WcTCS60"
    "https://ibb.co/k9xjnqF"
    "https://ibb.co/C2KmCdt"
    "https://ibb.co/86p3Gzf"
    "https://ibb.co/vkbC3Pv")


/**Grants */
let localesCreate = new Locales(null, null, 1, null, "Yerbal 740", "49026388", ["Suite ", "Suite con Hidromasaje", "Especial"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Almagro",
    "https://ibb.co/RQ54cwv",
    "https://ibb.co/bvz1yyM",
    "https://ibb.co/301FKDp",
    "https://ibb.co/FKSwZKk",
    "https://ibb.co/v3G2Vb2",
    "https://ibb.co/wynCVPg",
    "https://ibb.co/QpDjr4H")

/**Falcon */
let localesCreate = new Locales(null, null, 1, null, "Cnel. Ramón L. Falcón 1582", "44313167", ["Suite ", "Suite con Hidromasaje", "Especial"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Almagro", https: //ibb.co/LZ7fybZ
    "https://ibb.co/0hW3fWm",
    "https://ibb.co/PwZJxdG",
    "https://ibb.co/JqQ4GcL",
    "https://ibb.co/6gJgw4w",
    "https://ibb.co/XFYDXqr",
    "https://ibb.co/nmxTg76",
    "https://ibb.co/qmjjnJz",
    "https://ibb.co/kxyYLhj",
    "https://ibb.co/Jv9bGD7",
    "https://ibb.co/nLzLJ88")

/*------------------------------------------------------------------------*/

/**COMUNA 3 */

/**Almagro */
/**Diaz Velez */
let localesCreate = new Locales(null, null, 1, null, "Diaz Velez 3557", "48610466", ["Suite Alhambra", "Suite Raices", "Suite Tabues"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Almagro", "https://ibb.co/Hdg4b5g"
    "https://ibb.co/hDXFH4N"
    "https://ibb.co/bBdmBWx"
    "https://ibb.co/CnksR8b"
    "https://ibb.co/RTs89Bw"
    "https://ibb.co/F8jBw9n")

/**Valentino Hotel */
let localesCreate = new Locales(null, null, 1, null, "Carlos Calvo 3290", "4861-5053", ["Spa", "Hidromasaje"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Almagro", "https://ibb.co/4YD6fdK",
    "https://ibb.co/7p4v3bs",
    "https://ibb.co/8cYmgCw",
    "https://ibb.co/g3YDjq1", )

/**Armenon */

let localesCreate = new Locales(null, null, 1, null, "Sarmiento 3188", "48613040", ["Loft", "Especial", "Ejecutiva", "Strip Dance", "Hidrozono", "Especial", "Standard", "Kamasutra", "Ciclo Estrellas", "Noche Glactica"], "6500 a 4500", "Telo en barrio Almagro", "https://ibb.co/gzC9yDp",
    "https://ibb.co/7YNncwL",
    "https://ibb.co/LRq3rKj",
    "https://ibb.co/mGH1fp8",
    "https://ibb.co/fM3Mxts",
    "https://ibb.co/2d6SZL3".
    "https://ibb.co/C9mbgYw",
    "https://ibb.co/FghyK6P",
    "https://ibb.co/NKZbQfW",
    "https://ibb.co/xGmQrTx")

/**Dallas */

let localesCreate = new Locales(null, null, 1, null, "Ecuador 224", "48641650", ["Spa Dallas", "Loft Dallas", "Spa Mirador", "Iglu", "Eros", "Titanic", "Suite Caño", "Retro", "Suite Espejo", "Especial", "Suite con sillon erotico", "Suite Mediebal", "Caligula", "Suite Cochera Privada"], "2100 a 6100", "Telo en barrio Almagro", "https://ibb.co/55cb7jq",
    "https://ibb.co/nRS2sqh",
    "https://ibb.co/ggJtJnW",
    "https://ibb.co/x2MHmBD",
    "https://ibb.co/ckpt5C5",
    "https://ibb.co/H4VMXtm",
    "https://ibb.co/CvrZ319",
    "https://ibb.co/NVkbNw9",
    "https://ibb.co/MkBHsDn",
    "https://ibb.co/zsFKYcw",
    "https://ibb.co/j5X1J8T",
    "https://ibb.co/8D3g5TG")


/**Mansion Lirio */



/**San Cristobal-Boedo */
/**Bariloche */

let localesCreate = new Locales(null, null, 1, null, "Carlos Calvo 3290", "4932-5056", ["Bariloche", "Especial", "Suite", "Hidromasaje", "Normal"], "los precios no estan actualizados, comunicarse con el local para detalles de precio", "Telo en barrio Boedo", "https://ibb.co/ZxKQ0MD", "https://ibb.co/b2WtZCv", "https://ibb.co/YQjpKhm", "https://ibb.co/sQQhtvr", "https://ibb.co/KWB684q")