function Locales(localID, comunaID, nameL, addressL, webL, descriptionL, servicesL, priceRangeL, servicesL, imgLogo, img1, img2, img3, img4) {
    this.localID = localID,
        this.comunaID = comunaID,
        this.nameL = nameL,
        this.addressL = addressL,
        this.webL = webL,
        this.descriptionL = descriptionL,
        this.servicesL = servicesL,
        this.priceRangeL = priceRangeL,
        this.servicesL = servicesL,
        this.imgLogo = imgLogo,
        this.img1 = img1,
        this.img2 = img2,
        this.img3 = img3,
        this.img4 = img4,

}
Locales()
Locales(localID, comunaID, nameL, addressL, webL, descriptionL, servicesL, priceRangeL, servicesL, img1, img2, img3, img4, img5)

local00 = new Locales(localID, comunaID, nameL, addressL, webL, descriptionL, servicesL, priceRangeL, servicesL, img1, img2, img3, img4, img5)
local01 = newLocales(1, 1, 'Osiris', addressL, webL, descriptionL, servicesL, priceRangeL, servicesL, imgLogo, img1, img2, img3, img4)