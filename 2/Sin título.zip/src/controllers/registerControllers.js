// body requeste trae lo name del nuevo


let controller = {
    createE: (req, res) => {
        console.log(req.body) {
            "nameE": " ";
            "emailE": " ";
            "webE": " ";
            "emailE": " ";
            "checkE": " ";
            "notesE": " "
        }
        res.redirect(clubE)
    }
}